# EventManagerAndroid
Applicazione Android per il progetto EventManager
