package it.disi.unitn.lpsmt.progetto.lasagna.eventmanager.eventmanager.ui;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

// new since Glide v4
@GlideModule
public final class MyGlideModule extends AppGlideModule {
    // leave empty for now
}
