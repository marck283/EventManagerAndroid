package it.disi.unitn.lpsmt.progetto.lasagna.eventmanager.eventmanager.ui.user_calendar;

import androidx.lifecycle.ViewModel;

public class UserCalendarViewModel extends ViewModel {

    public void getPersonalEvents() {
        //Ottieni gli eventi del calendario personale
    }

}