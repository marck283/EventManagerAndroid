package it.disi.unitn.lpsmt.progetto.lasagna.eventmanager.eventmanager.ui.user_profile;

import androidx.lifecycle.ViewModel;

public class UserProfileViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}